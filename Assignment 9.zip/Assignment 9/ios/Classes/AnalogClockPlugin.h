#import <Flutter/Flutter.h>

@interface AnalogClockPlugin : NSObject<FlutterPlugin>
@end
